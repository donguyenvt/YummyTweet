//
//  TweetViewController.swift
//  YummyTweet
//
//  Created by Nguyen T Do on 3/27/16.
//  Copyright © 2016 Nguyen Do. All rights reserved.
//

import UIKit

class TweetViewController: UIViewController {
    
    @IBOutlet weak var profilePicImageView: UIImageView!
    @IBOutlet weak var userNameLabel: UILabel!
    @IBOutlet weak var userHandleLabel: UILabel!
    @IBOutlet weak var retweetCountLabel: UILabel!
    @IBOutlet weak var tweetTextLabel: UILabel!
    @IBOutlet weak var favoriteCountLabel: UILabel!
    @IBOutlet weak var tweetImageView: UIImageView!
    @IBOutlet weak var timestampLabel: UILabel!

    var tweet: Tweet!

    override func viewDidLoad() {
        super.viewDidLoad()

        tweetTextLabel.text = tweet.text
        tweetTextLabel.preferredMaxLayoutWidth = tweetTextLabel.frame.size.width
        
        if let user = tweet.user {
            let profileImageUrl = user.profileUrl
            if profileImageUrl != nil {
                profilePicImageView.setImageWithURL(profileImageUrl!)
            }
            userNameLabel.text = user.name
            userHandleLabel.text = "@\(user.screenName!)"
        }
        
        if let retweetCount = tweet.retweetCount {
            retweetCountLabel.text = "\(retweetCount)"
        }
        
        if let favoriteCount = tweet.favoriteCount {
            favoriteCountLabel.text = "\(favoriteCount)"
        }
        
        if  tweet.mediaURL != nil {
            tweetImageView.setImageWithURL(NSURL(string: tweet.mediaURL!)!)
        } else {
            tweetImageView.image = nil
        }
        
        timestampLabel.text = NSDateFormatter.localizedStringFromDate(tweet.timestamp!, dateStyle: .ShortStyle, timeStyle: .ShortStyle)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
