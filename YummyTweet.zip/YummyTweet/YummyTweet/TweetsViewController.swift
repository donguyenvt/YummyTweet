//
//  TweetsViewController.swift
//  YummyTweet
//
//  Created by Nguyen T Do on 3/26/16.
//  Copyright © 2016 Nguyen Do. All rights reserved.
//

import UIKit

class TweetsViewController: UIViewController {
    
    var tweets: [Tweet]!
    var refreshControl:UIRefreshControl!
    
    @IBOutlet weak var tableView: UITableView!

    override func viewDidLoad() {
        super.viewDidLoad()
        
        tableView.dataSource = self
        tableView.delegate = self
        tableView.rowHeight = UITableViewAutomaticDimension
        tableView.estimatedRowHeight = 200
        
        loadTweets(false)

        refreshControl = UIRefreshControl()
        refreshControl.attributedTitle = NSAttributedString(string: "Pull to refresh")
        refreshControl.addTarget(self, action: "refresh:", forControlEvents: UIControlEvents.ValueChanged)
        
        tableView.addSubview(refreshControl)
        
        tableView.addInfiniteScrollWithHandler { (scrollView) -> Void in
            let tableView = scrollView as! UITableView
            
            //
            // fetch your data here, can be async operation,
            // just make sure to call finishInfiniteScroll in the end
            //
            self.loadMoreTweets()
        }

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func refresh(sender: AnyObject) {
        print(sender)
        loadTweets(true)
    }
    
    func loadTweets(refreshing: Bool = false) {
        
        TwitterClient.sharedInstance.homeTimeline(nil, success: {(tweets: [Tweet]) -> () in
            self.tweets = tweets
            print("Tweet loads at refreshing: \(tweets.first?.text)")
            self.tableView.reloadData()
            
            if refreshing {
                self.refreshControl.endRefreshing()
            }
            
            }) { (error: NSError) -> () in
                print(error.localizedDescription)
        }
    }

    @IBAction func onLogoutButton(sender: AnyObject) {
        TwitterClient.sharedInstance.logout()
    }
    
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {

        if segue.identifier == "composeSegue" {
            if sender is UIButton {
                let retweetButton = sender as! UIButton
                let cell = retweetButton.superview?.superview as? TweetCell
                
                if cell != nil {
                    let tweet = cell!.tweet
                    let vc = segue.destinationViewController as! ComposeViewController
                    vc.replyToTweet = tweet
                    vc.replyToUser = tweet.user
                }
            }
        } else if segue.identifier == "singleTweetSegue" {
                    let cell = sender as? TweetCell
                    let vc = segue.destinationViewController as! TweetViewController
                    vc.tweet = cell?.tweet
        }
    }
}

extension TweetsViewController: UITableViewDataSource, UITableViewDelegate {
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return tweets?.count ?? 0
    }
    
    // Row display. Implementers should *always* try to reuse cells by setting each cell's reuseIdentifier and querying for available reusable cells with dequeueReusableCellWithIdentifier:
    // Cell gets various attributes set automatically based on table (separators) and data source (accessory views, editing controls)
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCellWithIdentifier("TweetCell", forIndexPath: indexPath) as! TweetCell
        cell.tweet = tweets![indexPath.row] as Tweet
        
        return cell
    }
    
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        tableView.deselectRowAtIndexPath(indexPath, animated: true)
    }
}
