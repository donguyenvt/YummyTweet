//
//  Tweet.swift
//  YummyTweet
//
//  Created by Nguyen T Do on 3/25/16.
//  Copyright © 2016 Nguyen Do. All rights reserved.
//

import UIKit

class Tweet: NSObject {
    
    var text: String?
    var timestamp: NSDate?
    var retweetCount: Int?
    var favoriteCount: Int?
    var user: User?
    
    var raw: NSDictionary
    var entities: NSDictionary?
    var media: [NSDictionary]?
    var mediaURL: String?    // let use String instead of NSURL
    
    static let dateFormatter = NSDateFormatter()
    
    init(dictionary: NSDictionary) {
        text = dictionary["text"] as? String
        raw = dictionary
        
        retweetCount = (dictionary["retweet_count"] as? Int) ?? 0
        favoriteCount = (dictionary["favourites_count"] as? Int) ?? 0
        
        // TODO: turn formatter into static
        let createdAtString = dictionary["created_at"] as? String
        Tweet.dateFormatter.dateFormat = "EEE MMM d HH:mm:ss Z y"
        timestamp = Tweet.dateFormatter.dateFromString(createdAtString!)
        
        entities = raw["entities"] as? NSDictionary
        media = entities?["media"] as? [NSDictionary]
        mediaURL = media?[0]["media_url"] as? String
        
        /*
        let timestampString = dictionary["created_at"] as? String
        
        if let timestampString = timestampString {
            let formatter = NSDateFormatter()
            formatter.dateFormat = "EEE MMM d HH:mm:ss Z y"     // This is a popular date format, save and reuse!
            timestamp = formatter.dateFromString(timestampString)
        }
        */
        user = User(dictionary: dictionary["user"] as! NSDictionary)
        
    }
    
    class func tweetsWithArray(dictionaries: [NSDictionary]) -> [Tweet] {   // Helper func because API (timeline)returns an array of dictionaries and we need to put them into our array.
        var tweets = [Tweet]()
        
        for dictionary in dictionaries {
            let tweet = Tweet(dictionary: dictionary)
            
            tweets.append(tweet)
        }
        
        return tweets
    }

}
