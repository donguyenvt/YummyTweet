//
//  TwitterClient.swift
//  YummyTweet
//
//  Created by Nguyen T Do on 3/26/16.
//  Copyright © 2016 Nguyen Do. All rights reserved.
//

import UIKit
import BDBOAuth1Manager

class TwitterClient: BDBOAuth1SessionManager {
    
    static let sharedInstance = TwitterClient(baseURL: NSURL(string: "https://api.twitter.com")!, consumerKey: "nXGKQU2M1PVfCSXaiyJ715Mr9", consumerSecret: "T9q40heWpFSTZ3iXtLlYsoz7r1vTk6xR6MsV9tdm1xtz9JA0zc")
    
    // Declare closures
    var loginSuccess: (() -> ())?
    var loginFailure: ((NSError) -> ())?
    
    func login(success: () -> (), failure: (NSError) -> ()) {
        loginSuccess = success
        loginFailure = failure
        
        TwitterClient.sharedInstance.deauthorize()
        TwitterClient.sharedInstance.fetchRequestTokenWithPath("oauth/request_token", method: "GET", callbackURL: NSURL(string: "yummytweet://oauth"), scope: nil, success:{ (requestToken: BDBOAuth1Credential!) -> Void in
            // print("I got a token!")
            let url = NSURL(string: "https://api.twitter.com/oauth/authorize?oauth_token=\(requestToken.token)")!
            UIApplication.sharedApplication().openURL(url)
            
        }) { (error: NSError!) -> Void in
            print("error: \(error.localizedDescription)")
            self.loginFailure?(error)
        }
    }
    
    func logout() {
        User.currentUser = nil
        deauthorize()
        
        // To go back the previous VC - use NSNotificationCenter
        NSNotificationCenter.defaultCenter().postNotificationName(User.userDidLogoutNotification, object: nil)   // AppDelegate will interest in this.
    }
    
    func handleOpenUrl(url: NSURL) {
        let requestToken = BDBOAuth1Credential(queryString: url.query)
        fetchAccessTokenWithPath("oauth/access_token", method: "POST", requestToken: requestToken, success: { (accessToken: BDBOAuth1Credential!) -> Void in
            print("I got the access token!")
            
            self.currentAccount({ (user: User) -> () in
                // This point we actually logged in.
                User.currentUser = user   // Will call the setter and save it.
                self.loginSuccess?()
            }, failure: { (error: NSError) -> () in
                    self.loginFailure?(error)
            })

        }) { (error: NSError!) -> Void in
            print("error: \(error.localizedDescription)")
            self.loginFailure?(error)
        }
    }
    
    func homeTimeline(params: NSDictionary?, success: ([Tweet]) -> (), failure: (NSError) -> ()) {   // NOTE: it takes time to fetch the data asynchronously, hence we cannot return data now. Instead, we return a closure which will execute if success.
        GET("1.1/statuses/home_timeline.json", parameters: params, progress: nil, success: { (task: NSURLSessionDataTask, response: AnyObject?) -> Void in   // When the network comes back, this closure will execute.
            let dictionaries = response as! [NSDictionary]   // The response is an array of dictionaries.
            let tweets = Tweet.tweetsWithArray(dictionaries)
            
            success(tweets)   // A sort of returning of closure :)
            
        }, failure: { (task: NSURLSessionDataTask?, error: NSError) -> Void in
            failure(error)
        })
    }
    
    func currentAccount(success: (User) -> (), failure: (NSError) -> ()) {
        GET("1.1/account/verify_credentials.json", parameters: nil, progress: nil, success: { (task: NSURLSessionDataTask, response: AnyObject?) -> Void in
            let userDictionary = response as! NSDictionary
            let user = User(dictionary: userDictionary)
            success(user)
            
        }, failure: { (task: NSURLSessionDataTask?, error: NSError) -> Void in
            failure(error)
        })
    }
    
    func postTweetWithParams(params: NSDictionary?, success: (Tweet) -> (), failure: (NSError) -> ()) {
        POST("1.1/statuses/update.json", parameters: params, progress: nil, success: { (task: NSURLSessionDataTask, response: AnyObject?) -> Void in
            let status = Tweet(dictionary: response as! NSDictionary)
            success(status)
            
        }, failure: { (task: NSURLSessionDataTask?, error: NSError) -> Void in
                failure(error)
        })
    }


}
