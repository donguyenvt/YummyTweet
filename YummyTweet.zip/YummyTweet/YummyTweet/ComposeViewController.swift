//
//  ComposeViewController.swift
//  YummyTweet
//
//  Created by Nguyen T Do on 3/27/16.
//  Copyright © 2016 Nguyen Do. All rights reserved.
//

import UIKit

class ComposeViewController: UIViewController {
    
    var replyToUser: User?
    var replyToTweet: Tweet?
    var replyId = 0

    @IBOutlet weak var profileImageView: UIImageView!
    @IBOutlet weak var composeTextField: UITextField!
    @IBOutlet weak var profileName: UILabel!
    @IBOutlet weak var profileHandle: UILabel!
    @IBOutlet weak var characterLeftLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let profileImageUrl = User.currentUser?.profileUrl
        if profileImageUrl != nil {
            profileImageView.setImageWithURL(profileImageUrl!)
        }
        profileName.text = User.currentUser?.name
        profileHandle.text = User.currentUser?.screenName

    }
    
    @IBAction func updateCharacterLeft(sender: AnyObject) {
        let soFar = composeTextField.text!.characters.count
        let remaining = 140 - soFar
        characterLeftLabel.text = "\(remaining)"
        if remaining <= 0 {  // What if the user pastes text kakaka.
            composeTextField.endEditing(true)
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func onTweetButton(sender: AnyObject) {
        
        print("tweeting: \(composeTextField.text)")
        
        let params = NSMutableDictionary()
        if (replyId > 0) {
            params.setValue(replyId, forKey: "in_reply_to_status_id")
        }
        params.setValue(composeTextField.text, forKey: "status")
        
        TwitterClient.sharedInstance.postTweetWithParams(params, success: { (tweet: Tweet) -> () in
            print(tweet)
            self.dismissViewControllerAnimated(true, completion: nil)
            
        }) { (error: NSError) -> () in
            print("Cannot post tweet due to \(error.localizedDescription)")
        }
    }
    
    @IBAction func onCancelButton(sender: AnyObject) {
        self.dismissViewControllerAnimated(true, completion: nil)
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
