//
//  TweetCell.swift
//  YummyTweet
//
//  Created by Nguyen T Do on 3/26/16.
//  Copyright © 2016 Nguyen Do. All rights reserved.
//

import UIKit

class TweetCell: UITableViewCell {

    @IBOutlet weak var profilePicImageView: UIImageView!
    @IBOutlet weak var userNameLabel: UILabel!
    @IBOutlet weak var tweetTextLabel: UILabel!
    @IBOutlet weak var userHandleLabel: UILabel!
    @IBOutlet weak var retweetCountLabel: UILabel!
    @IBOutlet weak var favoriteCountLabel: UILabel!
    @IBOutlet weak var timeAgoLabel: UILabel!
    @IBOutlet weak var tweetImageView: UIImageView!
    @IBOutlet weak var favoriteButton: UIButton!
    
    var tweet: Tweet! {
        didSet {
            tweetTextLabel.text = tweet.text
            tweetTextLabel.preferredMaxLayoutWidth = tweetTextLabel.frame.size.width
            
            let profileImageUrl = tweet.user?.profileUrl
            if profileImageUrl != nil {
                profilePicImageView.setImageWithURL(profileImageUrl!)
            }
            userNameLabel.text = tweet.user?.name
            userHandleLabel.text = "@\(tweet.user!.screenName!)"
            
            if let retweetCount = tweet.retweetCount {
                retweetCountLabel.text = "\(retweetCount)"
            }
            
            if let favoriteCount = tweet.favoriteCount {
                favoriteCountLabel.text = "\(favoriteCount)"
            }
            
            timeAgoLabel.text = timeElapsed(tweet.timestamp!)
            
            if  tweet.mediaURL != nil {
                tweetImageView.setImageWithURL(NSURL(string: tweet.mediaURL!)!)
            } else {
                tweetImageView.image = nil
            }
        }
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        self.profilePicImageView.layer.cornerRadius = 3
        self.profilePicImageView.clipsToBounds = true
    }

    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}

extension TweetCell {
    
    func timeElapsed(date: NSDate) -> String {
        if let hours = hoursFrom(date) {
            return "\(hours)h"
        } else if let minutes = minutesFrom(date) {
            return "\(minutes)m"
        } else {
            return "\(secondsFrom(date))s"
        }
    }
    
    func hoursFrom(date: NSDate) -> Int? {
        let hours = NSCalendar.currentCalendar().components(NSCalendarUnit.Hour, fromDate: date, toDate: NSDate(), options: []).hour
        if hours == 0 {
            return nil
        } else {
            return hours
        }
    }
    
    func minutesFrom(date: NSDate) -> Int? {
        let minutes = NSCalendar.currentCalendar().components(NSCalendarUnit.Minute, fromDate: date, toDate: NSDate(), options: []).minute
        if minutes == 0 {
            return nil
        } else {
            return minutes
        }
    }
    
    func secondsFrom(date: NSDate) -> Int {
        return NSCalendar.currentCalendar().components(NSCalendarUnit.Second, fromDate: date, toDate: NSDate(), options: []).second
    }

}
